import type { User } from "./types.js";

// Free public test API (no key required)
const API_URL = "https://jsonplaceholder.typicode.com/users";

async function loadUsers(): Promise<void> {
  const status = document.getElementById("status")!;
  const table = document.getElementById("usersTable") as HTMLTableElement;
  const tbody = table.querySelector("tbody")!;

  status.textContent = "Loading...";
  status.className = "";
  tbody.innerHTML = "";

  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error("HTTP error " + response.status);
    }

    const users: User[] = await response.json();
    console.log(users); // see raw data in DevTools (F12)

    users.forEach((user) => {
      const row = document.createElement("tr");
      [user.id, user.name, user.email, user.phone, user.address.city, user.company.name]
        .forEach((value) => {
          const cell = document.createElement("td");
          cell.textContent = String(value);
          row.appendChild(cell);
        });
      tbody.appendChild(row);
    });

    table.hidden = false;
    status.textContent = `Loaded ${users.length} users.`;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    status.textContent = "Failed to load data: " + message;
    status.className = "error";
  }
}

document.getElementById("loadBtn")!.addEventListener("click", loadUsers);
