// dashboard.ts — modern, self-contained users dashboard.
// Include the compiled output in any page: <script type="module" src="dist/dashboard.js"></script>
// It injects its own styles and renders into <div id="app"> (created if missing).

import type { User } from "./types.js";

type Theme = "light" | "dark";

const API_URL = "https://jsonplaceholder.typicode.com/users";

const STYLES = `
  :root {
    --bg: #f6f7fb; --surface: #ffffff; --text: #14161f; --muted: #6b7280;
    --border: #e5e7eb; --accent: #6366f1; --accent-2: #ec4899;
    --shadow: 0 1px 2px rgb(0 0 0 / .04), 0 8px 24px rgb(0 0 0 / .06);
    --radius: 16px;
  }
  :root[data-theme="dark"] {
    --bg: #0b0d14; --surface: #151823; --text: #eef0f6; --muted: #9aa1b2;
    --border: #262a38; --shadow: 0 1px 2px rgb(0 0 0 / .4), 0 8px 24px rgb(0 0 0 / .35);
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--text);
    font: 15px/1.5 Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    transition: background .25s, color .25s;
  }
  .wrap { max-width: 1120px; margin: 0 auto; padding: 32px 16px 64px; }
  header { display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
  h1 { margin: 0; font-size: clamp(1.6rem, 3vw, 2.2rem); letter-spacing: -.02em; }
  h1 span {
    background: linear-gradient(90deg, var(--accent), var(--accent-2));
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .sub { color: var(--muted); margin: 4px 0 0; }
  .toolbar { display: flex; gap: 10px; margin: 28px 0 20px; flex-wrap: wrap; }
  .search {
    flex: 1 1 260px; padding: 12px 16px; border-radius: 12px; font: inherit;
    border: 1px solid var(--border); background: var(--surface); color: var(--text);
    outline: none; transition: border-color .2s, box-shadow .2s;
  }
  .search:focus { border-color: var(--accent); box-shadow: 0 0 0 4px rgb(99 102 241 / .15); }
  .btn {
    padding: 12px 18px; border-radius: 12px; border: 1px solid var(--border);
    background: var(--surface); color: var(--text); font: inherit; font-weight: 600;
    cursor: pointer; transition: transform .15s, background .2s;
  }
  .btn:hover { transform: translateY(-1px); }
  .btn.primary { background: var(--accent); border-color: var(--accent); color: #fff; }
  .status { color: var(--muted); font-size: .9rem; margin-bottom: 16px; min-height: 1.5em; }
  .status.error { color: #ef4444; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; }
  .card {
    background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
    padding: 20px; box-shadow: var(--shadow);
    animation: rise .4s ease both; transition: transform .2s, border-color .2s;
  }
  .card:hover { transform: translateY(-3px); border-color: var(--accent); }
  .top { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
  .avatar {
    width: 44px; height: 44px; border-radius: 50%; display: grid; place-items: center;
    color: #fff; font-weight: 700; flex-shrink: 0;
  }
  .name { font-weight: 650; margin: 0; }
  .company { color: var(--muted); font-size: .85rem; margin: 0; }
  .row { display: flex; gap: 8px; font-size: .9rem; color: var(--muted); margin-top: 6px; overflow-wrap: anywhere; }
  .row a { color: var(--accent); text-decoration: none; }
  .tag {
    display: inline-block; margin-top: 14px; padding: 4px 10px; border-radius: 999px;
    font-size: .75rem; font-weight: 600; background: rgb(99 102 241 / .12); color: var(--accent);
  }
  .skeleton { height: 170px; border-radius: var(--radius); background: var(--surface);
    border: 1px solid var(--border); position: relative; overflow: hidden; }
  .skeleton::after { content: ""; position: absolute; inset: 0;
    background: linear-gradient(90deg, transparent, rgb(127 127 127 / .12), transparent);
    animation: shimmer 1.2s infinite; }
  .empty { grid-column: 1 / -1; text-align: center; color: var(--muted); padding: 48px 0; }
  @keyframes rise { from { opacity: 0; transform: translateY(8px); } }
  @keyframes shimmer { from { transform: translateX(-100%); } to { transform: translateX(100%); } }
  @media (prefers-reduced-motion: reduce) { *, *::after { animation: none !important; transition: none !important; } }
`;

const el = <K extends keyof HTMLElementTagNameMap>(
  tag: K,
  props: Partial<HTMLElementTagNameMap[K]> = {},
  ...children: (Node | string)[]
): HTMLElementTagNameMap[K] => {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
};

const initials = (name: string): string => name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
const hue = (id: number): number => (id * 47) % 360;

function userCard(user: User, index: number): HTMLElement {
  const avatar = el("div", { className: "avatar", textContent: initials(user.name) });
  avatar.style.background = `linear-gradient(135deg, hsl(${hue(user.id)} 75% 55%), hsl(${hue(user.id) + 40} 75% 55%))`;

  const card = el(
    "article",
    { className: "card" },
    el("div", { className: "top" }, avatar,
      el("div", {},
        el("p", { className: "name", textContent: user.name }),
        el("p", { className: "company", textContent: user.company.name }))),
    el("div", { className: "row" }, "✉️", el("a", { href: `mailto:${user.email}`, textContent: user.email })),
    el("div", { className: "row", textContent: `📞 ${user.phone}` }),
    el("span", { className: "tag", textContent: `📍 ${user.address.city}` })
  );
  card.style.animationDelay = `${index * 40}ms`;
  return card;
}

function createDashboard(root: HTMLElement): void {
  let users: User[] = [];

  const status = el("div", { className: "status" });
  const grid = el("div", { className: "grid" });
  const search = el("input", { className: "search", type: "search", placeholder: "Search by name, email, city or company…" });
  const reload = el("button", { className: "btn primary", textContent: "Reload" });
  const theme = el("button", { className: "btn", title: "Toggle theme" });

  const setTheme = (mode: Theme): void => {
    document.documentElement.dataset.theme = mode;
    theme.textContent = mode === "dark" ? "☀️ Light" : "🌙 Dark";
    try { localStorage.setItem("theme", mode); } catch {}
  };
  let saved: string | null = null;
  try { saved = localStorage.getItem("theme"); } catch {}
  setTheme(saved === "dark" || saved === "light"
    ? saved
    : matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  theme.onclick = () => setTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");

  const render = () => {
    const q = search.value.trim().toLowerCase();
    const list = users.filter((u) =>
      [u.name, u.email, u.address.city, u.company.name].some((v) => v.toLowerCase().includes(q)));
    grid.replaceChildren(...(list.length
      ? list.map(userCard)
      : [el("div", { className: "empty", textContent: "No users match your search." })]));
    status.textContent = `Showing ${list.length} of ${users.length} users`;
  };

  const load = async () => {
    status.className = "status";
    status.textContent = "Loading…";
    grid.replaceChildren(...Array.from({ length: 6 }, () => el("div", { className: "skeleton" })));
    try {
      const res = await fetch(API_URL);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      users = await res.json();
      render();
    } catch (err) {
      grid.replaceChildren();
      status.className = "status error";
      const message = err instanceof Error ? err.message : String(err);
      status.textContent = `Failed to load users: ${message}`;
    }
  };

  search.addEventListener("input", render);
  reload.addEventListener("click", load);

  root.replaceChildren(
    el("div", { className: "wrap" },
      el("header", {},
        el("div", {},
          Object.assign(el("h1"), { innerHTML: "Users <span>Dashboard</span>" }),
          el("p", { className: "sub", textContent: "Live data from JSONPlaceholder" })),
        theme),
      el("div", { className: "toolbar" }, search, reload),
      status,
      grid)
  );

  load();
}

document.head.append(el("style", { textContent: STYLES }));
const root = document.getElementById("app") ?? document.body.appendChild(el("div", { id: "app" }));
createDashboard(root);
