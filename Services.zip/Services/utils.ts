// utils module
console.log("Utils loaded");
