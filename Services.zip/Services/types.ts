// The fields we use from a JSONPlaceholder user record.
export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: { city: string };
  company: { name: string };
}
