# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

"Bluebird" (working name) is a small TypeScript project with no runtime dependencies. TypeScript is the only dev dependency, and there is no bundler, linter, or test framework. It is not a git repository.

## Building

Source `.ts` files sit in the project root and `tsc` compiles them into `dist/` (config in `tsconfig.json`). Run `npm install` once, then:

```
npm run build   # compile once (also reports type errors)
npm run watch   # recompile on change
```

Pages and scripts run the compiled output, so rebuild after changing a `.ts` file.

## Running

- **Browser pages** (`dashboard.html`, `api-test.html`) need to be served over HTTP. The VS Code launch config (`.vscode/launch.json`) expects a static server on `http://localhost:8080`, e.g.:
  ```
  npm run serve
  ```
  Then open `http://localhost:8080/dashboard.html` or use the "Launch Chrome against localhost" debug config.
- **Node scripts** (`index.ts`, `app.ts`, `main.ts`, `utils.ts`, `test.ts`) are standalone placeholders that just `console.log`. Run any one with `node dist/<file>.js`. They do not import each other, and `test.ts` is not a real test suite.

## Code style

- Always use named exports, never default exports.
- Write files in TypeScript.

## Architecture

Both browser pages fetch the same public test API, `https://jsonplaceholder.typicode.com/users` (no key needed), and render user records (`id`, `name`, `email`, `phone`, `address.city`, `company.name`). The `User` type for these records is in `types.ts`.

- `api-test.html` is a simple prototype with inline CSS. Its script is `api-test.ts`, which renders a table when you click a button.
- `dashboard.html` is just a shell (`<div id="app">` plus a module script tag loading `dist/dashboard.js`). All of the behavior lives in `dashboard.ts`, which:
  - injects its own stylesheet (the `STYLES` string) into `<head>`. Theming uses CSS custom properties on `:root`, with dark-mode overrides under `:root[data-theme="dark"]`.
  - builds the DOM with a small `el(tag, props, ...children)` helper (no framework). Use `textContent` for user data, not `innerHTML`.
  - mounts into `#app`, or creates it if it's missing, so the script can be dropped into any page.
  - keeps its state inside `createDashboard`'s closure: `users` holds the fetched data, and `render()` filters it by the search box and redraws the card grid. `load()` shows skeleton placeholders, fetches the data, and handles errors.
  - saves the theme choice to `localStorage` (wrapped in try/catch). If nothing is saved, it follows `prefers-color-scheme`.
